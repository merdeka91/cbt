INSERT INTO `cbt_modul` (`modul_id`, `modul_nama`, `modul_aktif`) VALUES ('1', 'Kelas X', 1);**;**;INSERT INTO `cbt_modul` (`modul_id`, `modul_nama`, `modul_aktif`) VALUES ('2', 'Kelas XI', 1);**;**;INSERT INTO `cbt_modul` (`modul_id`, `modul_nama`, `modul_aktif`) VALUES ('3', 'Kelas XII', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('101', '1', '10 Pendidikan Agama dan Budi Pekerti', '10 Pendidikan Agama dan Budi Pekerti', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('102', '1', '10 PPKn', '10 PPKn', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('103', '1', '10 Bahasa Indonesia', '10 Bahasa Indonesia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('104', '1', '10 Matematika Wajib', '10 Matematika Wajib', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('105', '1', '10 Sejarah Indonesia', '10 Sejarah Indonesia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('106', '1', '10 Bahasa Inggris', '10 Bahasa Inggris', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('107', '1', '10 Seni Budaya', '10 Seni Budaya', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('108', '1', '10 PJOK', '10 PJOK', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('109', '1', '10 PKWU', '10 PKWU', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('110', '1', '10 Bahasa Sunda', '10 Bahasa Sunda', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('111', '1', '10 Matematika Minat', '10 Matematika Minat', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('112', '1', '10 Biologi', '10 Biologi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('113', '1', '10 Fisika', '10 Fisika', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('114', '1', '10 Kimia', '10 Kimia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('115', '1', '10 Geografi', '10 Geografi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('116', '1', '10 Sejarah Minat', '10 Sejarah Minat', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('117', '1', '10 Sosiologi', '10 Sosiologi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('118', '1', '10 Ekonomi', '10 Ekonomi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('119', '1', '10 Bahasa dan Sastra Inggris', '10 Bahasa dan Sastra Inggris', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('120', '1', '10 Bahasa dan Sastra Jepang', '10 Bahasa dan Sastra Jepang', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('121', '1', '10 Informatika', '10 Informatika', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('201', '2', '11 Pendidikan Agama dan Budi Pekerti', '11 Pendidikan Agama dan Budi Pekerti', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('202', '2', '11 PPKn', '11 PPKn', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('203', '2', '11 Bahasa Indonesia', '11 Bahasa Indonesia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('204', '2', '11 Matematika Wajib', '11 Matematika Wajib', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('205', '2', '11 Sejarah Indonesia', '11 Sejarah Indonesia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('206', '2', '11 Bahasa Inggris', '11 Bahasa Inggris', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('207', '2', '11 Seni Budaya', '11 Seni Budaya', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('208', '2', '11 PJOK', '11 PJOK', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('209', '2', '11 PKWU', '11 PKWU', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('210', '2', '11 Bahasa Sunda', '11 Bahasa Sunda', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('211', '2', '11 Matematika Minat', '11 Matematika Minat', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('212', '2', '11 Biologi', '11 Biologi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('213', '2', '11 Fisika', '11 Fisika', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('214', '2', '11 Kimia', '11 Kimia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('215', '2', '11 Geografi', '11 Geografi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('216', '2', '11 Sejarah Minat', '11 Sejarah Minat', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('217', '2', '11 Sosiologi', '11 Sosiologi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('218', '2', '11 Ekonomi', '11 Ekonomi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('219', '2', '11 Bahasa dan Sastra Inggris', '11 Bahasa dan Sastra Inggris', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('220', '2', '11 Bahasa dan Sastra Jepang', '11 Bahasa dan Sastra Jepang', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('221', '2', '11 Informatika', '11 Informatika', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('301', '3', '12 Pendidikan Agama dan Budi Pekerti', '12 Pendidikan Agama dan Budi Pekerti', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('302', '3', '12 PPKn', '12 PPKn', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('303', '3', '12 Bahasa Indonesia', '12 Bahasa Indonesia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('304', '3', '12 Matematika Wajib', '12 Matematika Wajib', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('305', '3', '12 Sejarah Indonesia', '12 Sejarah Indonesia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('306', '3', '12 Bahasa Inggris', '12 Bahasa Inggris', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('307', '3', '12 Seni Budaya', '12 Seni Budaya', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('308', '3', '12 PJOK', '12 PJOK', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('309', '3', '12 PKWU', '12 PKWU', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('310', '3', '12 Bahasa Sunda', '12 Bahasa Sunda', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('311', '3', '12 Matematika Minat', '12 Matematika Minat', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('312', '3', '12 Biologi', '12 Biologi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('313', '3', '12 Fisika', '12 Fisika', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('314', '3', '12 Kimia', '12 Kimia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('315', '3', '12 Geografi', '12 Geografi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('316', '3', '12 Sejarah Minat', '12 Sejarah Minat', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('317', '3', '12 Sosiologi', '12 Sosiologi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('318', '3', '12 Ekonomi', '12 Ekonomi', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('319', '3', '12 Bahasa dan Sastra Inggris', '12 Bahasa dan Sastra Inggris', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('320', '3', '12 Bahasa dan Sastra Jepang', '12 Bahasa dan Sastra Jepang', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('321', '3', '12 Informatika', '12 Informatika', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('322', '3', 'Simulasi 1', 'Simulasi 1', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('323', '3', 'Simulasi 2', 'Simulasi 2', 1);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('215', '322', '
			<p>Diketahui 3 orang anak Jojo, Faiz, dan Jiman sedang makan siang hari ini dan beberapa pernyataan berikut menunjukkan kondisi yang terjadi :</p>

			<ul>
				<li>Jojo makan ayam atau nasi Goreng</li>
				<li>Jika ada dua orang yang makan Ayam maka satu orang lainnya pasti makan nasi Goreng</li>
				<li>Jika Faiz makan ayam maka Jojo makan nasi Goreng</li>
				<li>Satu orang memiliki makanan yang berbeda dari kedua orang lainnya</li>
				<li>Setiap orang hanya memilih satu jenis makanan</li>
			</ul>

			<p>Dari pernyataan di atas siapa saja kah yang makan siangnya dipastikan adalah nasi Goreng?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('216', '322', '<p><img src=\"[base_url]uploads/topik_322/6295ba832162a.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('217', '322', '
			<p>Leinad adalah seorang guru. Ia memiliki sejumlah permen dan 23 orang murid. Jika 5 orang tidak hadir permen sisa 9. Jika 8 orang tidak hadir, permen sisa 12. Jika 3 orang tidak hadir, permen sisa 17. Jika, sekarang ia memiliki 15 permen, berapa banyak permen tambahan minimum yang harus Leinad beli?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('218', '322', '
			<p>Perhatikan pernyataan-pernyataan berikut!</p>

			<ul>
				<li>Pak Dengklek suka berbagi</li>
				<li>Jika Pak Dengklek ke pantai maka ia menyumbang satu quintal beras</li>
				<li>Pak Dengklek menyumbang satu quintal beras jika dan hanya jika ia memiliki cukup rupiah</li>
				<li>Pak Dengklek akan berbagi buah-buahan jika ia makan makanan mewah</li>
				<li>Pak Dengklek akan berbagi buah-buahan jika dan hanya jika ia menyumbang satu quintal beras</li>
				<li>Jika Pak Dengklek berbagi buah-buahan maka ia memiliki cukup rupiah</li>
				<li>Pak dengklek pergi ke pantai dan ia akan bermain air di sana</li>
			</ul>

			<p>Jika seluruh pernyataan di atas benar, maka pernyataan yang bisa salah adalah?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('219', '322', '<p>Perhatikan gambar berikut.</p>

<p><img src=\"[base_url]uploads/topik_322/6295bbd4e4dc4.png\" /></p>

<p>Nama perangkat tersebut adalah</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('220', '322', '
			<p>Magenta ingin mengirim kartu pos kepada n temannya. Dia ingin membuat kartu pos dengan tangannya sendiri. Untuk itu, dia mempunyai selembar kertas berukuran w x h dan dia mempunyai dua aturan:</p>

			<ul>
				<li>Jika w genap, maka Magenta dapat memotong setengahnya dan mendapatkan dua lembar kertas berukuran w/2 x h.</li>
				<li>Jika h genap, maka Magenta dapat memotong setengahnya dan mendapatkan dua lembar kertas berukuran w x h/2.</li>
			</ul>

			<p>Jika w dan h sama-sama genap, maka Magenta bebas menggunakan dua aturan di atas. Setelah memotong kertas, jumlah kertas yang dipunyainya akan bertambah satu. Kertas hasil potongan dapat dipotong</p>

			<p>kembali asal memperhatikan urutan.</p>

			<p>Bantu Magenta untuk memilih kemungkinan mana yang mungkin dia bisa memotong kertas w x h sehingga jumlahnya lebih dari cukup untuk dibagikan kepada n temannya?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('221', '322', '
			<p>Rarqi adalah seorang paman yang baik. Ia senang membagikan permen untuk keponakan-keponakannya. Suatu hari Rarqi membawa sejumlah permen di kantongnya. Jika ia membagikan permen-permen tersebut kepada 3 keponakannya sama rata, maka permennya akan bersisa 1 buah. Jika dibagikan kepada 5 keponakannya sama rata, maka permennya bersisa 4 buah. Sementara jika dia membagikan kepada 7 keponakannya, maka akan bersisa 6 buah. Berapa banyak permen yang dibawah Rarqi saat itu?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('222', '322', '<p>Ada berapa segitiga yang bisa dibentuk?</p>

<p><img src=\"[base_url]uploads/topik_322/6295be67b879f.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('223', '322', '<p>Alamat sekolah yang memiliki logo seperti dibawah adalah:</p>

<p><img src=\"[base_url]uploads/topik_322/6295beb52d19f.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('224', '322', '
			<p>Di kantin SMAN 1 Garut terdapat 5 orang murid yang sedang antri membeli roti. Kelima murid tersebut adalah Hakan, Nazan, Eva, Ali, dan Budi. Kasir toko sambil melayani pembeli, dia juga mengamati urutan posisi kelima mahasiswa tersebut. Hakan tidak di depan. Nazan tepat didepan Eva yang berdiri diurutan kedua. Ali di belakang Hakan. Budi di urutan kedua dari belakang.</p>

			<p>Siapakah yang antri di posisi ke-3 dari depan?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('225', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bc52403d9.png\" /></p>

<p>Benua Afrika ditunjukan oleh warna?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('226', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bc8f29e77.png\" /></p>

<p>Nama hewan tersebut adalah?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('227', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bcd576957.png\" /></p>

<p>Bangunan tersebut berada dinegara</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('228', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bd1411d91.png\" /></p>

<p>Nama buah tersebut adalah?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('229', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bd4cc52fb.png\" /></p>

<p>Nama bunga tersebut adalah?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('230', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bd6ba7ddd.png\" /></p>

<p>Nama rempah diatas adalah?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('231', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bd9197a78.png\" /></p>

<p>Nama rempah diatas adalah?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('232', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bdca94bae.png\" /></p>

<p>Nama tokoh tersebut adalah?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('233', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295bdf76530d.png\" /></p>

<p>Nama pantai yang memiliki maskot gambar diatas adalah?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('234', '322', '<p>Perhatikan gambar berikut!</p>

<p><img src=\"[base_url]uploads/topik_322/6295be1b0168b.png\" /></p>

<p>Nama hewan diatas adalah?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('235', '322', '
			<p>Negara yang tidak termasuk anggota ASEAN adalah</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('236', '322', '
			<p>Alamat SMAN 1 Garut adalah?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('237', '322', '
			<p>Lambang dari sila ke-3 Pancasila adalah</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('238', '322', '
			<p>Bilangan bulat yang paling bulat adalah?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('239', '322', '
			<p>Rumus Kimia <strong><strong>Sodium Hydroxide</strong></strong>&nbsp;adalah?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('240', '322', '
			<p>Nilai dari &Ecirc;&#131; 6x<sup>2</sup>&nbsp;dx adalah?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('241', '322', '
			<p>Gerakan suatu benda dimana setiap titik pada benda tersebut mempunyai jarak yang tetap terhadap suatu sumbu tertentu, merupakan pengertian dari</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('242', '322', '
			<p>Sebuah balok bermassa 1,5 kg didorong ke atas oleh gaya konstan F = 15 N pada bidang miring seperti gambar. Anggap percepatan gravitasi (g) 10 ms<sup>-2</sup>&nbsp;dan gesekan antara balok dan bidang miring nol. Usaha total yang dilakukan pada balok adalah ...</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('243', '322', '
			<p>Planet urutan ke empat di tata surya tempat Bumi berada adalah?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('244', '322', '
			<p>1 1 2 3 5 8 13 &hellip;</p>

			<p>Lanjutan pola tersebut adalah</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('245', '323', '
			<p>Bintang street number 20<br>
			STAR Children Devepment Consultant</p>

			<p>May 5, 2016</p>

			<p>Dear, Mrs. Vivian Ferisa</p>

			<p style=\"text-align:justify\">Our company has read your proposal regarding to children development conference. With this letter, we inform that we are interested to be your partner to hold the conference. We will send you email about our concept, plan, and design of the event. We need to have meeting to discuss it. Please kindly inform us your availibility to attend the meeting.</p>

			<p style=\"text-align:justify\">We look forward to hearing from you soon. Thank you very much for your kind attention.</p>

			<p>Best regards,<br>
			Mr. Hemmy Lawanata</p>

			<p>The purpose of sending the letter is&hellip;..</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('246', '323', '
			<p>Bintang street number 20<br>
			STAR Children Devepment Consultant</p>

			<p>May 5, 2016</p>

			<p>Dear, Mrs. Vivian Ferisa</p>

			<p style=\"text-align:justify\">Our company has read your proposal regarding to children development conference. With this letter, we inform that we are interested to be your partner to hold the conference. We will send you email about our concept, plan, and design of the event. We need to have meeting to discuss it. Please kindly inform us your availibility to attend the meeting.</p>

			<p style=\"text-align:justify\">We look forward to hearing from you soon. Thank you very much for your kind attention.</p>

			<p>Best regards,<br>
			Mr. Hemmy Lawanata</p>

			<p>&nbsp;</p>

			<p>We know from the text that the theme of the event will be about&hellip;..</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('248', '323', '
			<p style=\"text-align:justify\"><strong><strong>My first time experience in Bali</strong></strong></p>

			<p style=\"text-align:justify\">At 55 I have just gone to Bali for the first time with my husband. We stayed in Seminyak and had a wonderful time. We took Jetstar in economy over and were in 2nd last row and even then by time off plane purchasing VOA and Immigration took about 1 hour - wasn\'t too bad. Departing last night, Jetstar was late by one hour but we had paid to go Business class so it was not that bad. We sat in Premier Lounge - not a great selection of food or wine (wine is my thing) but it was enjoyable anyway. Of course, new airport is underway and things may be different once that is up and running. We didn\'t get sick or robbed or bitten. Yes, footpaths are broken and or missing and some smells but that didn\'t 16<em><em>deter&nbsp;</em></em>us. People were friendly and so polite. The weather was just fantastic. When asked to take what looked like post cards we politely said \"no thank you \" and that was the last of it. Bintang beer mostly $2.50 very cheap and was the food and we ate in good restaurants - La Lucciola, Breeze, Sardine, Sarong and Metis. As we had breakfast supplied at The Samaya we didn\'t need lunch and we were given fruit salad by the pool and afternoon tea so only dinner was required. We enjoyed Sarong in particular. We used hand sanitizer and luckily for us we didn\'t get the dreaded dire - rear. A driver took us to Ubud and Jimbaran Bay and through Kuta. Mostly this was a relaxing one week there. Manicures, pedicures, hair, massage were so cheap - roughly $8 - we had these done at Body Works in Seminyak. I also had Wendy the dressmaker come to our hotel and made me skirts which I was very happy with. This morning in Sydney airport, it took us just 30 minutes to be off the plane and into a taxi. Jetstar made up time flying home - only 5 hours and 10 minutes. It was all a breeze. Bali had never been on my to do list, but I will be going back that is for sure.</p>

			<p style=\"text-align:justify\">Sumber:&nbsp;https://www.tripadvisor.com</p>

			<p style=\"text-align:justify\">&nbsp;</p>

			<p>What happened when they were about to leave for Bali?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('249', '323', '
			<p style=\"text-align:justify\">Rina : What are you thinking about?</p>

			<p style=\"text-align:justify\">Dino : I&rsquo;m thinking about my plan after graduating from Senior High School.</p>

			<p style=\"text-align:justify\">Rina : Can you tell me your plan?</p>

			<p style=\"text-align:justify\">Dino : My parents asked me to study in Turkey since its higher education there is cheaper than here. But, it&rsquo;s kind of hard for me to live far away from my family. What about yours?</p>

			<p style=\"text-align:justify\">Rina : I think it&rsquo;s a good idea. Living far away from your parents will teach you how to be an independent man. I&rsquo;ll be studying at IIUM majoring in international relations. I want to be a diplomat.</p>

			<p style=\"text-align:justify\">Dino : That sounds great. It means that you&rsquo;re going to live far away from your parents as well?</p>

			<p style=\"text-align:justify\">Rina : Yes. I want to be independent. Of course, I&rsquo;ll be missing them, but I think it&rsquo;s going to be a great challenge for me.</p>

			<p style=\"text-align:justify\">&nbsp;What is the main topic of the conversation above?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('250', '323', '
			<p style=\"text-align:justify\"><strong><strong>HOW TO CREATE A PAYPAL ACCOUNT</strong></strong></p>

			<p style=\"text-align:justify\">Visit the PayPal website or open the PayPal app. You can create an account from the PayPal homepage or from the app. You can install the app for free from your device\'s app store. The account creation process is largely the same for both the website and the app.</p>

			<p style=\"text-align:justify\">Click \"Sign Up for Free\" or tap \"Sign Up\". This will begin the account creation process.</p>

			<p style=\"text-align:justify\">&middot; For business accounts, there are two different options, each of which has different cost structures and benefits. Standard accounts are free, but customers must route through PayPal in order to check out. Pro accounts cost $30 per month, but you get to full control over how you want to design the checkout process.</p>

			<p style=\"text-align:justify\">&middot; The Standard free business account is the same as the old PayPal Premier account. This account is best suited for users who do lots of buying and selling on eBay.</p>

			<p style=\"text-align:justify\">Enter your email address and create a password. Make sure that you create a strong password so that nobody else can access your financial information.</p>

			<p style=\"text-align:justify\">&middot; Make sure that you enter a valid email address, as you\'ll need to use it to verify your account.</p>

			<p style=\"text-align:justify\">Fill out the form with your personal information. You\'ll need to enter your legal name, address, and phone number. All of this information is required in order to create your account.</p>

			<p style=\"text-align:justify\">Enter your credit or debit card (optional). After entering your personal information, you\'ll be prompted to enter your credit or debit card. You can enter this now or later, but you\'ll need to at some point if you want to verify your PayPal account.</p>

			<p style=\"text-align:justify\">&middot; If you don\'t want to enter your card information now, click \"I\'d rather link my bank first\".</p>

			<p style=\"text-align:justify\">Enter your bank account information (optional). You\'ll need a bank account linked if you plan on receiving money and want to be able to transfer it to your bank. You don\'t have to do this now if you don\'t want to. Just click \"I\'ll link my bank later\" to skip it for now. You\'ll be prompted to confirm that you want to skip the process.</p>

			<p style=\"text-align:justify\">Apply for PayPal credit (optional). Before you\'re taken to your account\'s Summary page, PayPal will prompt you to sign up for a line of credit. This is optional, and you should read all of the terms carefully before applying. If you\'d rather not apply for credit, click \"No thanks\".</p>

			<p style=\"text-align:justify\">Sumber: https://www.wikihow.com</p>

			<p>&nbsp;</p>

			<p>What is the purpose of the text above?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('251', '323', '
			<p style=\"text-align:justify\"><strong><strong>HOW TO CREATE A PAYPAL ACCOUNT</strong></strong></p>

			<p style=\"text-align:justify\">Visit the PayPal website or open the PayPal app. You can create an account from the PayPal homepage or from the app. You can install the app for free from your device\'s app store. The account creation process is largely the same for both the website and the app.</p>

			<p style=\"text-align:justify\">Click \"Sign Up for Free\" or tap \"Sign Up\". This will begin the account creation process.</p>

			<p style=\"text-align:justify\">&middot; For business accounts, there are two different options, each of which has different cost structures and benefits. Standard accounts are free, but customers must route through PayPal in order to check out. Pro accounts cost $30 per month, but you get to full control over how you want to design the checkout process.</p>

			<p style=\"text-align:justify\">&middot; The Standard free business account is the same as the old PayPal Premier account. This account is best suited for users who do lots of buying and selling on eBay.</p>

			<p style=\"text-align:justify\">Enter your email address and create a password. Make sure that you create a strong password so that nobody else can access your financial information.</p>

			<p style=\"text-align:justify\">&middot; Make sure that you enter a valid email address, as you\'ll need to use it to verify your account.</p>

			<p style=\"text-align:justify\">Fill out the form with your personal information. You\'ll need to enter your legal name, address, and phone number. All of this information is required in order to create your account.</p>

			<p style=\"text-align:justify\">Enter your credit or debit card (optional). After entering your personal information, you\'ll be prompted to enter your credit or debit card. You can enter this now or later, but you\'ll need to at some point if you want to verify your PayPal account.</p>

			<p style=\"text-align:justify\">&middot; If you don\'t want to enter your card information now, click \"I\'d rather link my bank first\".</p>

			<p style=\"text-align:justify\">Enter your bank account information (optional). You\'ll need a bank account linked if you plan on receiving money and want to be able to transfer it to your bank. You don\'t have to do this now if you don\'t want to. Just click \"I\'ll link my bank later\" to skip it for now. You\'ll be prompted to confirm that you want to skip the process.</p>

			<p style=\"text-align:justify\">Apply for PayPal credit (optional). Before you\'re taken to your account\'s Summary page, PayPal will prompt you to sign up for a line of credit. This is optional, and you should read all of the terms carefully before applying. If you\'d rather not apply for credit, click \"No thanks\".</p>

			<p>Sumber: https://www.wikihow.com</p>

			<p>&nbsp;</p>

			<p>The sentence&nbsp;<em><em>&lsquo;You can create an account from the PayPal homepage or from the app.&rsquo;</em></em>&nbsp;could possibly restated as&hellip;</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('252', '323', '
			<p style=\"text-align:justify\">A volcano is an opening in the Earth&rsquo;s surface where molten rock can escape from underneath. The Earth&rsquo;s surface is made up of tectonic plates, which are spreading apart, crunching into each other, or sliding beside one another. Volcanoes are typically found at the fault lines between these plates. There can be&nbsp;active volcanoes, which are currently, or have recently erupted. There are also dormant volcanoes, which haven&rsquo;t erupted recently, and extinct volcanoes, which will never erupt again.</p>

			<p style=\"text-align:justify\">There are 4 major types of volcanoes:</p>

			<p style=\"text-align:justify\"><strong><strong>Cinder Cone Volcanoes</strong></strong></p>

			<p style=\"text-align:justify\">These are the simplest type of volcano. They occur when particles and blobs of lava are ejected from a volcanic vent. The lava is blown violently into the air, and the pieces rain down around the vent. Over time, this builds up a circular or oval-shaped cone, with a bowl-shaped crater at the top. Cinder cone volcanoes rarely grow larger than about 1,000 feet above their surroundings.</p>

			<p style=\"text-align:justify\"><strong><strong>Composite Volcanoes</strong></strong></p>

			<p style=\"text-align:justify\">Composite volcanoes, or strato volcanoes make up some of the world&rsquo;s most memorable mountains: Mount Rainier, Mount Fuji, and Mount Cotopaxi, for example. These volcanoes have a conduit system inside them that channels magma from deep within the Earth to the surface. They can have clusters of vents, with lava breaking through walls, or issuing from fissures on the sides of the mountain. With all this material coming out, they can grow thousands of meters tall. As we&rsquo;ve seen with the famous Mount Saint Helens, composite volcanoes can explode violently.</p>

			<p style=\"text-align:justify\"><strong><strong>Shield Volcanoes</strong></strong></p>

			<p style=\"text-align:justify\">These are large, broad volcanoes that look like shields from above &ndash; hence the name. The lava that pours out of shield volcanoes is thin, so it can travel for great distances down the shallow slopes of the volcano. These volcanoes build up slowly over time, with hundreds of eruptions, creating many layers. They&rsquo;re not likely to explode catastrophically. Perhaps the best-known shield volcanoes are the ones that make up the Hawaiian Islands, especially Mauna Loa and Mauna Kea.</p>

			<p style=\"text-align:justify\"><strong><strong>Lava Domes</strong></strong></p>

			<p style=\"text-align:justify\">Volcanic or lava domes are created by small masses of lava which are too viscous (thick) to flow very far. Unlike shield volcanoes, with low-viscosity lava, the magma from volcanic domes just piles up over and around the vent. The dome grows by expansion of the lava within, and the mountain forms from material spilling off the sides of the growing dome. Lava domes can explode violently, releasing a huge amount of hot rock and ash.</p>

			<p style=\"text-align:justify\">Sumber: https://www.universetoday.com</p>

			<p>What is the topic of the passage above?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('253', '323', '
			<p style=\"text-align:justify\">A volcano is an opening in the Earth&rsquo;s surface where molten rock can escape from underneath. The Earth&rsquo;s surface is made up of tectonic plates, which are spreading apart, crunching into each other, or sliding beside one another. Volcanoes are typically found at the fault lines between these plates. There can be&nbsp;active volcanoes, which are currently, or have recently erupted. There are also dormant volcanoes, which haven&rsquo;t erupted recently, and extinct volcanoes, which will never erupt again.</p>

			<p style=\"text-align:justify\">There are 4 major types of volcanoes:</p>

			<p style=\"text-align:justify\"><strong><strong>Cinder Cone Volcanoes</strong></strong></p>

			<p style=\"text-align:justify\">These are the simplest type of volcano. They occur when particles and blobs of lava are ejected from a volcanic vent. The lava is blown violently into the air, and the pieces rain down around the vent. Over time, this builds up a circular or oval-shaped cone, with a bowl-shaped crater at the top. Cinder cone volcanoes rarely grow larger than about 1,000 feet above their surroundings.</p>

			<p style=\"text-align:justify\"><strong><strong>Composite Volcanoes</strong></strong></p>

			<p style=\"text-align:justify\">Composite volcanoes, or strato volcanoes make up some of the world&rsquo;s most memorable mountains: Mount Rainier, Mount Fuji, and Mount Cotopaxi, for example. These volcanoes have a conduit system inside them that channels magma from deep within the Earth to the surface. They can have clusters of vents, with lava breaking through walls, or issuing from fissures on the sides of the mountain. With all this material coming out, they can grow thousands of meters tall. As we&rsquo;ve seen with the famous Mount Saint Helens, composite volcanoes can explode violently.</p>

			<p style=\"text-align:justify\"><strong><strong>Shield Volcanoes</strong></strong></p>

			<p style=\"text-align:justify\">These are large, broad volcanoes that look like shields from above &ndash; hence the name. The lava that pours out of shield volcanoes is thin, so it can travel for great distances down the shallow slopes of the volcano. These volcanoes build up slowly over time, with hundreds of eruptions, creating many layers. They&rsquo;re not likely to explode catastrophically. Perhaps the best-known shield volcanoes are the ones that make up the Hawaiian Islands, especially Mauna Loa and Mauna Kea.</p>

			<p style=\"text-align:justify\"><strong><strong>Lava Domes</strong></strong></p>

			<p style=\"text-align:justify\">Volcanic or lava domes are created by small masses of lava which are too viscous (thick) to flow very far. Unlike shield volcanoes, with low-viscosity lava, the magma from volcanic domes just piles up over and around the vent. The dome grows by expansion of the lava within, and the mountain forms from material spilling off the sides of the growing dome. Lava domes can explode violently, releasing a huge amount of hot rock and ash.</p>

			<p style=\"text-align:justify\">Sumber: https://www.universetoday.com</p>

			<p>Which volcano has low-viscosity lava?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('254', '323', '
			<p style=\"text-align:justify\">Budi : Excuse me. I&rsquo;d like to borrow this book.</p>

			<p style=\"text-align:justify\">Librarian : Can you show me your library card?</p>

			<p style=\"text-align:justify\">Budi : Here it is&hellip; How many days can I borrow this book?</p>

			<p style=\"text-align:justify\">Librarian : You can borrow this book for one week. If you return this book late. You&rsquo;ll be fined Rp. 2.000 per day.</p>

			<p style=\"text-align:justify\">Budi : Okay. Thanks, Sir. I&rsquo;ll try to return this book on time.</p>

			<p style=\"text-align:justify\">&nbsp;Where does the dialogue take place?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('255', '323', '
			<p style=\"text-align:justify\">Fadli : Look at this, Putri! I passed the math test with an A.</p>

			<p style=\"text-align:justify\">Putri : &hellip; You finally conquered the test! Congratulations.</p>

			<p style=\"text-align:justify\">Fadli : I would not make it without you, Putri. You&rsquo;re a very excellent teacher. You taught me how to pass the test.</p>

			<p style=\"text-align:justify\">Putri : Don&rsquo;t mention it. That&rsquo;s what friends are supposed to do.</p>

			<p style=\"text-align:justify\">&nbsp;What is the appropriate sentence to fill the gap above?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('256', '323', '
			<p style=\"text-align:justify\">1. Anies Rasyid Baswedan was born on 7 May 1969.</p>

			<p style=\"text-align:justify\">2. He was also a rector of a private university before being appointed as a minister.</p>

			<p style=\"text-align:justify\">3. He is an Indonesian academic, activist, and politician.</p>

			<p style=\"text-align:justify\">4. Before being a governor, he served as Minister of Education and Culture.</p>

			<p style=\"text-align:justify\">5. He has currently served as Governor of Jakarta since October 2017.</p>

			<p style=\"text-align:justify\">Sumber:&nbsp;<em><em>https://en.wikipedia.org</em></em></p>

			<p style=\"text-align:justify\">&nbsp;Arrange the sentences above based on the appropriate procedural text&hellip;.</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('257', '323', '
			<p style=\"text-align:justify\">1. Ong&rsquo;s lawyer Eddie Koh will be making representations to the court. The case will next be mentioned in December.</p>

			<p style=\"text-align:justify\">2. The incident was captured in a two-minute video and uploaded on YouTube.</p>

			<p style=\"text-align:justify\">3. The man who pushed an old woman down a bus along Upper Thomson Road has been charged in court.</p>

			<p style=\"text-align:justify\">4. Ong is said to have used his right hand to push the old woman on her back, causing her to fall on the steps of the bus.</p>

			<p style=\"text-align:justify\">5. Twenty-five-year-old Ong Kok Hao is accused of hurting 76-year-old Hwang Li Lian Nee Lye on bus service number 167 at about 3pm on June 5 this year.</p>

			<p style=\"text-align:justify\">6. A shouting match then ensued and during the heated spat, Ong threatened to slap the woman, before pushing her down the bus.</p>

			<p style=\"text-align:justify\">7. The video shows Ong suddenly flying into a rage at Madam Hwang for pressing the bell at the last-minute along Upper Thomson Road.</p>

			<p style=\"text-align:justify\">Sumber:&nbsp;<em><em>https://luthfan.com</em></em></p>

			<p style=\"text-align:justify\">&nbsp;</p>

			<p style=\"text-align:justify\">Arrange the sentences above based on the appropriate procedural text&hellip;.</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('258', '323', '
			<p style=\"text-align:justify\">Nadia: Why does our village always get flood as peak rainy season approaches? What should we do?<br>
			Andy: ...........</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('259', '323', 'Sarah: Well, I am actually tired of taking a math course.<br>
			Ari: Why?<br>
			Sarah: The formula makes me confused. ..................<br>
			Ari: You\'d better pay more attention.', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('262', '323', '
			<p style=\"text-align:center\">PUBLIC NOTICE</p>

			<p style=\"text-align:justify\">This is to inform all members of Staff and the General Public that the Consulate General of the Federal Republic of Nigeria, Atlanta, will be closed on Monday November 11, 2019 to observe the Veteran\'s Day holiday declared by the United States Government.</p>

			<p style=\"text-align:justify\">2. Normal business will resume on Thursday, November 12, 2019.</p>

			<p style=\"text-align:center\">Consulate General of Nigeria, Atlanta</p>

			<p>What is the purpose of the text?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('263', '323', '
			<p>X: You look so tired&hellip;. did you walk?<br>
			Y: More than six kilometres, I think.</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('264', '323', '
			<p>Nadia: Why does our village always get flood as peak rainy season approaches? What should we do?<br>
			Andy: ...........</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('265', '323', '
			<p>Sarah: Well, I am actually tired of taking a math course.<br>
			Ari: Why?<br>
			Sarah: The formula makes me confused. ..................<br>
			Ari: You\'d better pay more attention.</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('266', '323', '
			<p style=\"text-align:justify\">The Proclamation of Indonesian Independence was read at 10.00 a.m. on Friday, 17 August 1945. The document was signed by Sukarno and Mohammad Hatta, who were appointed president and vice-president respectively the following day. The draft was prepared only a few hours earlier on the night of 16 August 1945 by Sukarno, Hatta, and Soebardjo, at the house of Rear-Admiral Tadashi Maeda.</p>

			<p style=\"text-align:justify\">The wording of the proclamation had been discussed at length and had to balance both conflicting internal Indonesian and Japanese interests. Sukarno drafted the final proclamation which balanced the interests of both the members of the youth movement and the Japanese. The term &lsquo;TRANSFER OF POWER&rsquo; was used in Indonesian to satisfy Japanese interests to appear that it was an administrative transfer of power, although the term used &lsquo;pemindahan kekuasaan&rsquo; could be perceived to mean political power. The wording &lsquo;BY CAREFUL MEANS&rsquo; related to preventing conflict with members of the youth movement. The wording &lsquo;IN THE SHORTEST POSSIBLE TIME&rsquo; was used to meet the needs of all Indonesians for independence.</p>

			<p style=\"text-align:justify\">Initially the proclamation was to be announced at Djakarta central square, but the military had been sent to monitor the area, so the venue was changed to Sukarno\'s house at Pegangsaan Timur 56. The proclamation was heard throughout the country because the text was&nbsp;<strong><em><strong><em>secretly</em></strong></em></strong>&nbsp;broadcast by Indonesian radio personnel using the transmitters of the Jakarta Broadcasting Station.</p>

			<p style=\"text-align:justify\">&nbsp;</p>

			<p>What is the main idea of the second paragraph?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('267', '323', '
			<p>Boy : Hey, what are you doing?<br>
			Girl : I&rsquo;d like to take the book on the top of the shelf, but I can&rsquo;t reach it.<br>
			Boy : Which book?<br>
			Girl : That one. It&rsquo;s entitled Creative Ideas. Boy : &hellip;&hellip;..</p>

			<p><br>
			How will the boy likely respond?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('268', '323', '
			<p style=\"text-align:justify\">Man: Uncle Dan is going to visit us this weekend.</p>

			<p style=\"text-align:justify\">Woman : That is great! We can spend all day in the city with him.</p>

			<p style=\"text-align:justify\">Man: Yeah, we can go to the cinema and try new cafes.</p>

			<p style=\"text-align:justify\">Woman: I can&rsquo;t wait to see him</p>

			<p style=\"text-align:justify\">&nbsp;</p>

			<p>What are the man and the woman talking about?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('269', '323', '
			<p style=\"text-align:justify\">Man : So, how was your trip?</p>

			<p style=\"text-align:justify\">Woman : It was awful. The committee was not professional. I lost a bag but they didn&rsquo;t do anything about it.</p>

			<p style=\"text-align:justify\">Man : That is bad. Well, at least the tour was great, wasn&rsquo;t it?</p>

			<p style=\"text-align:justify\">Woman : No, it wasn&rsquo;t. We just stayed at the hotel because it rained all day. They didn&rsquo;t predict the weather. Boring!</p>

			<p style=\"text-align:justify\">Man : Let me guess. The hotel was terrible as well?</p>

			<p style=\"text-align:justify\">Woman : You bet!</p>

			<p style=\"text-align:justify\">&nbsp;</p>

			<p>What does the woman express?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('270', '323', '
			<p>Alice: I\'ve got terrible toothache.<br>
			Ayu: You ........ go to the dentist.<br>
			&nbsp;</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('271', '323', '
			<p style=\"text-align:justify\">Ridho: I accidentally broke Dity\'s glasses I don\'t know what to do.<br>
			Marty: If I were you, I .............. tell her. Even though I know she\'d be angry.</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('272', '323', '
			<p style=\"text-align:justify\">A train accident occurred in northern Italy. The train traveled at 180 mph when the first car on the train left the rails and separated from the train. It hit a nearby railroad building, killed two railway workers, and injured 27 people.</p>

			<p style=\"text-align:justify\">Police explained that there was some work on the railway the evening before; however, work on railways happens very often. Police have to investigate the accident because they do not know if the work caused the accident.</p>

			<p style=\"text-align:justify\">Rail workers&rsquo; unions will go on strike on Friday. They said that the accident was very serious and not acceptable.</p>

			<p>What happened after the incident?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('273', '323', '
			<p style=\"text-align:justify\">Thomas Matulessy, also known as Kapitan Pattimura or Ahmad Lussy or simply Pattimura, was an Ambonese soldier and National Hero of Indonesia. Born on the island of Saparua, Pattimura joined the British army after they took the Maluku islands from the Dutch colonials. When the islands were returned to the Dutch in 1816, he was dismissed. Concerned that the Dutch would implement programs that limited his people, Pattimura led an armed rebellion that captured Fort Duurstede on 16 May 1817. Killing the inhabitants of the fortress and fighting off Dutch reinforcements, on 29 May he was declared the leader of the Maluku people. After being betrayed by the King of Booi Pati Akoon, he was captured by Dutch forces on 11 November and hanged the next month.</p>

			<p style=\"text-align:justify\">Pattimura has become a symbol of both Maluku and Indonesian independence, praised by President Sukarno and declared a national hero by President Suharto. He has several namesakes both in the capital of Maluku, Ambon, and in the rest of the Indonesian archipelago.</p>

			<p>What can we infer from the monologue?</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('274', '323', '
			<p style=\"text-align:justify\">The Proclamation of Indonesian Independence was read at 10.00 a.m. on Friday, 17 August 1945. The document was signed by Sukarno and Mohammad Hatta, who were appointed president and vice-president respectively the following day. The draft was prepared only a few hours earlier on the night of 16 August 1945 by Sukarno, Hatta, and Soebardjo, at the house of Rear-Admiral Tadashi Maeda.</p>

			<p style=\"text-align:justify\">The wording of the proclamation had been discussed at length and had to balance both conflicting internal Indonesian and Japanese interests. Sukarno drafted the final proclamation which balanced the interests of both the members of the youth movement and the Japanese. The term &lsquo;TRANSFER OF POWER&rsquo; was used in Indonesian to satisfy Japanese interests to appear that it was an administrative transfer of power, although the term used &lsquo;pemindahan kekuasaan&rsquo; could be perceived to mean political power. The wording &lsquo;BY CAREFUL MEANS&rsquo; related to preventing conflict with members of the youth movement. The wording &lsquo;IN THE SHORTEST POSSIBLE TIME&rsquo; was used to meet the needs of all Indonesians for independence.</p>

			<p style=\"text-align:justify\">Initially the proclamation was to be announced at Djakarta central square, but the military had been sent to monitor the area, so the venue was changed to Sukarno\'s house at Pegangsaan Timur 56. The proclamation was heard throughout the country because the text was&nbsp;<strong><em><strong><em>secretly</em></strong></em></strong>&nbsp;broadcast by Indonesian radio personnel using the transmitters of the Jakarta Broadcasting Station.</p>

			<p style=\"text-align:justify\">&nbsp;</p>

			<p><em><em>&ldquo;the text was&nbsp;</em></em><strong><em><u><strong><u><em>secretly&nbsp;</em></u></strong></u></em></strong><em><em>broadcast&rdquo;&nbsp;</em></em>(Par. 3). The underlined word has similar meaning to &hellip;.</p>
			', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('275', '323', '<p>Add the correct data type for the following variables:</p>

<pre>
___ var1 = 5.99;
___ var2 = 5;
___ var3 = &quot;Da&quot;;</pre>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('276', '323', '<p>Use the correct&nbsp;<strong>format specifier</strong>&nbsp;to output the value of&nbsp;<code>myNum</code>:</p>

<pre>
int myNum = 15;
printf(&quot;___&quot;, myNum);</pre>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('277', '323', '<p>Use the correct&nbsp;<strong>format specifier</strong>&nbsp;to output the value of&nbsp;<code>myNum</code>:</p>

<pre>
float myNum = 15.50;
printf(&quot;___&quot;, myNum);</pre>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('626', '215', '
			<p>Jojo</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('627', '215', '
			<p>Faiz</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('628', '215', '
			<p>Jiman</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('629', '215', '
			<p>Tidak dapat disimpulkan</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('630', '215', '
			<p>A,B, dan C menunjukkan pilihan yang benar</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('631', '216', '<p><img src=\"[base_url]uploads/topik_322/6295bac8ecb82.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('632', '216', '<p><img src=\"[base_url]uploads/topik_322/6295bb4b50f9d.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('633', '216', '<p><img src=\"[base_url]uploads/topik_322/6295bab576ef7.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('634', '216', '<p><img src=\"[base_url]uploads/topik_322/6295bb5e1f516.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('926', '216', '<p><img src=\"[base_url]uploads/topik_322/6295badc45e59.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('636', '217', '
			<p>100</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('637', '217', '
			<p>101</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('638', '217', '
			<p>102</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('639', '217', '
			<p>103</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('640', '217', '
			<p>104</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('641', '218', '
			<p>Pak Dengklek akan berbagi buah-buahan</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('642', '218', '
			<p>Pak Dengklek akan menyumbang satu quintal beras</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('643', '218', '
			<p>Pak Dengklek makan makanan mewah</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('644', '218', '
			<p>Pak Dengklek akan bermain air</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('645', '218', '
			<p>Dari pilihan a-d tidak ada pernyataan yang bisa salah</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('650', '219', '<p>printer</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('927', '219', '<p>monitor</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('928', '219', '<p>mouse</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('929', '219', '<p>keyboard</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('930', '219', '<p>speaker</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('651', '220', '
			<p>w = 6, h = 8, n = 13</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('652', '220', '
			<p>w = 22, h = 28, n = 7</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('653', '220', '
			<p>w = 7, h = 16, n = 26</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('654', '220', '
			<p>w = 24, h = 12, n = 28</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('655', '220', '
			<p>w = 10, h = 8, n = 11</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('656', '221', '
			<p>136</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('657', '221', '
			<p>137</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('658', '221', '
			<p>138</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('659', '221', '
			<p>139</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('660', '221', '
			<p>140</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('661', '222', '
			<p>76</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('662', '222', '
			<p>78</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('663', '222', '
			<p>81</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('664', '222', '
			<p>84</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('665', '222', '
			<p>Tidak ada jawaban yang benar</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('931', '223', '<p>Jl. Merdeka No. 91</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('932', '223', '<p>Jl. Pangeran Hidayatullah No. 62</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('933', '223', '<p>Jl. Nusantara Raya No.317</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('934', '223', '<p>Jl. Ir. H. Juanda No.16</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('935', '223', '<p>Jl. Gn. Galuh No.37</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('671', '224', '
			<p>Hakan</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('672', '224', '
			<p>Nazan</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('673', '224', '
			<p>Eva</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('674', '224', '
			<p>Ali</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('675', '224', '
			<p>Budi</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('676', '225', '
			<p>Hijau</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('677', '225', '
			<p>Merah</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('678', '225', '<p>Hitam</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('679', '225', '
			<p>Biru</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('680', '225', '
			<p>Putih</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('681', '226', '
			<p>Zebra</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('682', '226', '
			<p>Kuda</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('683', '226', '
			<p>Kudanil</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('684', '226', '
			<p>Kambing</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('685', '226', '
			<p>Sapi</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('686', '227', '
			<p>Italia</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('687', '227', '
			<p>Irlandia</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('688', '227', '
			<p>India</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('689', '227', '
			<p>Indonesia</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('690', '227', '
			<p>Inggris</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('691', '228', '
			<p>Melon</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('692', '228', '
			<p>Mangga</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('693', '228', '
			<p>Manggis</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('694', '228', '
			<p>Merkisa</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('695', '228', '
			<p>Semangka</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('696', '229', '
			<p>Mawar</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('697', '229', '
			<p>Malati</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('698', '229', '
			<p>Anggrek</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('699', '229', '
			<p>Sedap Malam</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('700', '229', '
			<p>Tulip</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('701', '230', '
			<p>Jahe</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('702', '230', '
			<p>Lengkuas</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('703', '230', '
			<p>Kunyit</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('704', '230', '
			<p>Kencur</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('705', '230', '
			<p>Temulawak</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('706', '231', '
			<p>Kemiri</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('707', '231', '
			<p>Lada</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('708', '231', '
			<p>Ketumbar</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('709', '231', '
			<p>Pala</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('710', '231', '
			<p>Kayu manis</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('711', '232', '
			<p>Ki Hajar Dewantara</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('712', '232', '
			<p>Ir. Soekarno</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('713', '232', '
			<p>H.O.S Cokroaminoto</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('714', '232', '
			<p>Si Singamangaradja XII</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('715', '232', '
			<p>Sultan Hasanuddin</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('716', '233', '
			<p>Sayang Heulang</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('717', '233', '
			<p>Santolo</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('718', '233', '
			<p>Puncak Guha</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('719', '233', '
			<p>Ranca Buaya</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('720', '233', '
			<p>Manalus</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('721', '234', '
			<p>Buaya</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('722', '234', '
			<p>Biawak</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('723', '234', '
			<p>Komodo</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('724', '234', '
			<p>Kadal</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('725', '234', '
			<p>Cacing</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('726', '235', 'Kamboja', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('727', '235', 'Vietnam', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('728', '235', 'Indonesia', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('729', '235', 'Thailand', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('730', '235', 'Timor Leste', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('731', '236', '
			<p>Jl. Merdeka No. 81</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('732', '236', '
			<p>Jl. Merdeka No. 51</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('733', '236', '
			<p>Jl. Merdeka No. 61</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('734', '236', '
			<p>Jl. Merdeka No. 71</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('735', '236', '
			<p>Jl. Merdeka No. 91</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('736', '237', '
			<p>bintang</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('737', '237', '
			<p>rantai</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('738', '237', '
			<p>pohon beringin</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('739', '237', '
			<p>kepala banteng</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('740', '237', '
			<p>padi dan kapas</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('741', '238', '
			<p>0</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('742', '238', '
			<p>10</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('743', '238', '
			<p>20</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('744', '238', '
			<p>8</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('745', '238', '
			<p>1</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('746', '239', '
			<p>NaOH</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('747', '239', '
			<p>HCl</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('748', '239', '
			<p>NaCl</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('749', '239', '
			<p>SiOH</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('750', '239', '
			<p>KOH</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('751', '240', '
			<p>2x<sup>3</sup>&nbsp;+ c</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('752', '240', '
			<p>2x<sup>3</sup></p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('753', '240', '
			<p>12x + c</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('754', '240', '
			<p>12</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('755', '240', '
			<p>x + c</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('756', '241', '
			<p>Gerak tranlasi</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('757', '241', '
			<p>Gerak rotasi</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('758', '241', '
			<p>Perpindahan</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('759', '241', '
			<p>Kelajuan</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('760', '241', '
			<p>Kecepatan</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('761', '242', '
			<p>15 J</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('762', '242', '
			<p>30 J</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('763', '242', '
			<p>45 J</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('764', '242', '
			<p>35 J</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('765', '242', '
			<p>50 J</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('768', '243', '
			<p>Venus</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('769', '243', '
			<p>Jupiter</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('770', '243', '
			<p>Pluto</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('766', '243', '
			<p>Bumi</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('767', '243', '
			<p>Mars</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('771', '244', '
			<p>20</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('772', '244', '
			<p>21</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('773', '244', '
			<p>22</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('774', '244', '
			<p>23</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('775', '244', '
			<p>24</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('776', '245', '
			<p>enclose the design of the event</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('777', '245', '
			<p>confirm the participation in the event as partner.</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('778', '245', '
			<p>arrange the meeting of an event preparation</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('779', '245', '
			<p>inform the date of an event.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('780', '245', '
			<p>Parents development</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('781', '246', '
			<p>Children party</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('782', '246', '
			<p>Children development</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('783', '246', '
			<p>Parenting conference</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('784', '246', '
			<p>Parents development</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('785', '246', '
			<p>inform the date of an event.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('791', '248', '
			<p>They needed to cancel their trip.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('792', '248', '
			<p>They needed to put their trip off.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('793', '248', '
			<p>The plane crashed.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('794', '248', '
			<p>The adverse weather prompted the plane to delay.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('795', '248', '
			<p>The plane was late for an hour.</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('796', '249', '
			<p>Studying in Turkey is cheaper</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('797', '249', '
			<p>Asking suggesting about study</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('798', '249', '
			<p>Discussing about plan after graduation</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('799', '249', '
			<p>Living far away from parents is difficult</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('800', '249', '
			<p>Majoring in politics is great</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('801', '250', '
			<p>To describe what the PayPal website is</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('802', '250', '
			<p>To give a brief hint how to use PayPal credit</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('803', '250', '
			<p>To explain how to register a new bank account</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('804', '250', '
			<p>To explain how to verify your PayPal account</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('805', '250', '
			<p>To explain how to create a PayPal account</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('806', '251', '
			<p>You need to create an account with both the PayPal homepage and the app.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('807', '251', '
			<p>You can make an account either from the PayPal homepage or the app.</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('808', '251', '
			<p>You don&rsquo;t need to create an account from the PayPal homepage or from the app.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('809', '251', '
			<p>You are obliged to create an account on the PayPal homepage and the app.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('810', '251', '
			<p>You can only create an account from the PayPal homepage not the app.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('811', '252', '
			<p>The definition of volcano</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('812', '252', '
			<p>The classification of volcano</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('813', '252', '
			<p>The meaning of volcano</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('814', '252', '
			<p>The classification of shield volcano</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('815', '252', '
			<p>The definition of composite volcano</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('816', '253', '
			<p>Composite volcano</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('817', '253', '
			<p>Shield volcano</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('818', '253', '
			<p>Explosion volcano</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('819', '253', '
			<p>Cinder Cone</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('820', '253', '
			<p>Lava volcano</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('821', '254', '
			<p>In the principle&rsquo;s room</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('822', '254', '
			<p>At office</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('823', '254', '
			<p>In the library</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('824', '254', '
			<p>In the classroom</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('825', '254', '
			<p>In the teachers&rsquo; room</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('826', '255', '
			<p>That\'s too bad!</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('827', '255', '
			<p>I can&rsquo;t believe this!</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('828', '255', '
			<p>You could do much better!</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('829', '255', '
			<p>I can&rsquo;t trust you!</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('830', '255', '
			<p>How bad it is!</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('831', '256', '
			<p>1 &ndash; 3 &ndash; 5 &ndash; 4 &ndash; 2</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('832', '256', '
			<p>1 &ndash; 3 &ndash; 5 &ndash; 2 &ndash; 4</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('833', '256', '
			<p>1 &ndash; 3 &ndash; 4 &ndash; 5 &ndash; 2</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('834', '256', '
			<p>3 &ndash; 1 &ndash; 5 &ndash; 4 &ndash; 2</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('835', '256', '
			<p>3 &ndash; 5 &ndash; 1 &ndash; 4 &ndash; 2</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('836', '257', '
			<p>3 &ndash; 4 &ndash; 5 &ndash; 2 &ndash; 7 &ndash; 6 &ndash; 1</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('837', '257', '
			<p>3 &ndash; 4 &ndash; 5 &ndash; 2 &ndash; 7 &ndash; 1 &ndash; 6</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('838', '257', '
			<p>3 &ndash; 5 &ndash; 4 &ndash; 2 &ndash; 7 &ndash; 6 &ndash; 1</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('839', '257', '
			<p>3 &ndash; 5 &ndash; 4 &ndash; 2 &ndash; 7 &ndash; 1 &ndash; 6</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('840', '257', '
			<p>5 &ndash; 3 &ndash; 4 &ndash; 2 &ndash; 7 &ndash; 1 &ndash; 6</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('841', '258', 'I think we should clean the river from trashes', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('842', '258', 'We should go fishing when the flood comes', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('843', '258', 'You ought to discuss it with your teacher', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('844', '258', 'What do you advise me to do?', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('845', '258', 'Great! We can swim together', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('846', '259', 'What do you advise me to do?', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('847', '259', 'What is the best answer?', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('848', '259', 'What do you expect?', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('849', '259', 'What do you hope?', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('850', '259', 'What do you want?', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('861', '262', '
			<p>To inform public holidays in Nigeria.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('862', '262', '
			<p>To announce the Veteran\'s Day celebration.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('863', '262', '
			<p>To invite the staff of the Consulate General of Nigeria to the White House.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('864', '262', '
			<p>To tell Nigeria about the Veteran\'s Day hold by the United States of America.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('865', '262', '
			<p>To announce the Consulate General of Nigeria closing due to the US Veteran&rsquo;s Day</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('866', '263', '
			<p>how far</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('867', '263', '
			<p>how long</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('868', '263', '
			<p>how many</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('869', '263', '
			<p>how big</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('870', '263', '
			<p>How much</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('871', '264', '
			<p>I think we should clean the river from trashes</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('872', '264', '
			<p>We should go fishing when the flood comes</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('873', '264', '
			<p>You ought to discuss it with your teacher</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('874', '264', '
			<p>What do you advise me to do?</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('875', '264', '
			<p>Great! We can swim together</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('876', '265', '
			<p>What do you advise me to do?</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('877', '265', '
			<p>What is the best answer?</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('878', '265', '
			<p>What do you expect?</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('879', '265', '
			<p>What do you hope?</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('880', '265', '
			<p>What do you want?</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('881', '266', '
			<p>The location of the proclamation.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('882', '266', '
			<p>The night before the proclamation.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('883', '266', '
			<p>The term &lsquo;TRANSFER OF POWER&rsquo;.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('884', '266', '
			<p>Word choice in the text of proclamation.</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('885', '266', '
			<p>The preparation of Indonesian independence</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('886', '267', '
			<p>Don&rsquo;t worry. I&rsquo;ll take it for you</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('887', '267', '
			<p>I think the book is interesting to read</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('888', '267', '
			<p>I believe many people will read the book</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('889', '267', '
			<p>I am proud of having a friend who likes reading</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('890', '267', '
			<p>I&rsquo;ve read the book</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('891', '268', '
			<p>Weekend plans</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('892', '268', '
			<p>Seeing a movie</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('893', '268', '
			<p>Going to the city</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('894', '268', '
			<p>Trying new cafes</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('895', '268', '
			<p>Uncle Dan&rsquo;s activities</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('896', '269', '
			<p>Hope</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('897', '269', '
			<p>Sympathy</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('898', '269', '
			<p>Satisfaction</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('899', '269', '
			<p>Expectation</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('900', '269', '
			<p>Dissatisfaction</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('901', '270', '
			<p>Better</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('902', '270', '
			<p>Are better</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('903', '270', '
			<p>Has better</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('904', '270', '
			<p>Can better</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('905', '270', 'Had better', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('906', '271', 'Can', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('907', '271', 'Might', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('908', '271', 'Could', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('909', '271', 'Would', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('910', '271', 'Should', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('911', '272', '
			<p>The railway was closed.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('912', '272', '
			<p>A protest would be held.</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('913', '272', '
			<p>Police would close the case.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('914', '272', '
			<p>The government would take action.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('915', '272', '
			<p>People became afraid to take the train</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('916', '273', '
			<p>The Dutch took Maluku from the British.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('917', '273', '
			<p>Pattimura was born in a nationalist family.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('918', '273', '
			<p>Pattimura was executed to stop the rebellion.</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('919', '273', '
			<p>Thomas Matulessy joined the British army to fight the Dutch.</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('920', '273', '
			<p>Pattimura was declared the leader of the Maluku people by Suharto</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('921', '274', '
			<p>continuously</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('922', '274', '
			<p>formally</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('923', '274', '
			<p>openly</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('924', '274', '
			<p>publicly</p>
			', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('925', '274', '
			<p>quietly</p>
			', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('936', '275', '<p>float, int, char[]</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('937', '275', '<p>float, int, string</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('938', '275', '<p>float, int, char</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('939', '275', '<p>float, integer, char</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('940', '275', '<p>float, integer, string</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('941', '276', '<p>%d</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('942', '276', '<p>%f</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('943', '276', '<p>%s</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('944', '276', '<p>%c</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('945', '276', '<p>%dl</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('946', '277', '<p>%f</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('947', '277', '<p>%d</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('948', '277', '<p>%nt</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('949', '277', '<p>%s</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('950', '277', '<p>%c</p>
', 0, 1);**;**;